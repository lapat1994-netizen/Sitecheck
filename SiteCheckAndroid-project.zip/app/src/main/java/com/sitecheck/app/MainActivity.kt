package com.sitecheck.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class Site(val name: String, val host: String)
data class Result(val ping: Long?, val http: Int?, val error: String?)

class MainActivity : Activity() {
    private val sites = listOf(
        Site("YouTube", "youtube.com"),
        Site("Telegram", "telegram.org"),
        Site("Google", "google.com"),
        Site("WhatsApp", "whatsapp.com"),
        Site("Discord", "discord.com"),
        Site("Instagram", "instagram.com"),
        Site("X (Twitter)", "x.com")
    )
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var content: LinearLayout
    private lateinit var checkButton: Button
    private val rows = mutableMapOf<String, TextView>()
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 21, 34)
        window.navigationBarColor = Color.rgb(16, 21, 34)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(18))
            setBackgroundColor(Color.rgb(16, 21, 34))
        }
        val title = TextView(this).apply {
            text = "SiteCheck"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        outer.addView(title)
        val subtitle = TextView(this).apply {
            text = "Проверка сайтов и задержки через текущее подключение"
            textSize = 14f
            setTextColor(Color.rgb(166, 179, 202))
            setPadding(0, dp(6), 0, dp(18))
        }
        outer.addView(subtitle)

        checkButton = Button(this).apply {
            text = "Проверить все сайты"
            isAllCaps = false
            setOnClickListener { runChecks() }
        }
        outer.addView(checkButton)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(12))
        }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "Пинг = время TCP-подключения. HTTP-код показывает ответ сайта. Результаты зависят от VPN и сети."
            textSize = 12f
            setTextColor(Color.rgb(142, 155, 178))
            setPadding(0, dp(10), 0, 0)
        }
        outer.addView(footer)
        setContentView(outer)
        sites.forEach { addSiteRow(it) }
    }

    private fun addSiteRow(site: Site) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            setBackgroundColor(Color.rgb(27, 35, 52))
        }
        val name = TextView(this).apply {
            text = "${site.name}  ·  ${site.host}"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val status = TextView(this).apply {
            text = "Ожидает проверки"
            textSize = 14f
            setTextColor(Color.rgb(166, 179, 202))
            setPadding(0, dp(5), 0, 0)
        }
        card.addView(name)
        card.addView(status)
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })
        rows[site.host] = status
    }

    private fun runChecks() {
        if (running) return
        running = true
        checkButton.isEnabled = false
        checkButton.text = "Проверка..."
        sites.forEach { rows[it.host]?.apply {
            text = "Проверяется..."
            setTextColor(Color.rgb(255, 204, 102))
        } }
        executor.execute {
            sites.forEach { site ->
                val result = check(site.host)
                main.post { showResult(site.host, result) }
            }
            main.post {
                running = false
                checkButton.isEnabled = true
                checkButton.text = "Проверить все сайты"
            }
        }
    }

    private fun check(host: String): Result {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL("https://$host/")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "HEAD"
                connectTimeout = 7000
                readTimeout = 7000
                instanceFollowRedirects = true
                useCaches = false
            }
            val start = System.nanoTime()
            connection.connect()
            val ping = (System.nanoTime() - start) / 1_000_000
            val code = connection.responseCode
            Result(ping, code, null)
        } catch (e: Exception) {
            Result(null, null, e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    private fun showResult(host: String, result: Result) {
        val view = rows[host] ?: return
        if (result.ping != null) {
            view.text = "Пинг: ${result.ping} мс   •   HTTP: ${result.http}"
            view.setTextColor(if (result.http in 200..399) Color.rgb(111, 220, 157) else Color.rgb(255, 204, 102))
        } else {
            view.text = "Нет ответа   •   ${result.error ?: "ошибка"}"
            view.setTextColor(Color.rgb(255, 125, 125))
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
